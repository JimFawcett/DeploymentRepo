/* module display */

pub fn message(m: &str) {
    println!("\n  {:?}\n", m);
}
