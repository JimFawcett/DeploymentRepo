/*
  demo1
  Demonstrate git operations
*/
mod display;

fn main() {
    let mut msg = "Hello git demo".to_owned();
    msg += " via module";
    msg += " display::message(m:&str)";
    display::message(msg.as_str());
}
